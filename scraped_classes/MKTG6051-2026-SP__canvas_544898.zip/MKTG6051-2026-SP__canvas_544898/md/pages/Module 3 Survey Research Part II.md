## Module 3: Survey Research Part II

### Learning Objectives

* Survey questionnaire design
  + Best practices for survey design
  + How to design survey questions that get the highest quality response
* Sampling and Sampling size

### To-Do This Module

* Tuesday

1. [Survey Design Your Respondents Will Love](https://www.qualtrics.com/experience-management/research/how-to-make-a-survey/) - Qualtrics
2. [The Qualtrics handbook of question design](https://canvas.umn.edu/courses/544898/files/58179450?verifier=Y3sk0BIPmdvdGLoldvs6VvKvsrNxtYSOU7UY9h9d&wrap=1 "The Qualtrics handbook of question design.pdf")

* Thursday

1. [5 Common Errors in the Research Process](https://www.qualtrics.com/blog/5-common-errors-in-the-research-process/) - Qualtrics
2. [How many survey responses do I need to be statistically valid? Find your sample size](https://www.surveymonkey.com/curiosity/how-many-people-do-i-need-to-take-my-survey/) - SurveyMonkey
3. [Getting great survey results from MTurk and Qualtrics](https://blog.mturk.com/getting-great-survey-results-from-mturk-and-qualtrics-be1704ff9786) - Mturk

### Additional Resources

* [Social Media Surveys](https://www.surveymonkey.com/mp/social-media-surveys/) - SurveyMonkey
* [Market Research Surveys](https://www.surveymonkey.com/mp/market-research-surveys/) - SurveyMonkey
* [Online Questionnaires - Crafting Better Questions](https://www.surveymonkey.com/learn/survey-best-practices/online-questionnaires/) - SurveyMonkey
* [5 Common Survey Question Mistakes That'll Ruin Your DataLinks to an external site.](https://www.surveymonkey.com/mp/5-common-survey-mistakes-ruin-your-data/) - SurveyMonkey
* [11 Tips for Building Effective SurveysLinks to an external site.](https://www.qualtrics.com/blog/10-tips-for-building-effective-surveys/) - Qualtrics
* [How to increase response rates survey](https://canvas.umn.edu/courses/544898/files/58179448?verifier=3z58gye43hrhNc2pnrHtHBs1VMfDeYaMYVd9gTuw&wrap=1 "Qualtrics increase response rates survey.pdf") - Qualtrics
* [SurveyMonkey Survey Templates](https://www.surveymonkey.com/mp/survey-templates/)
* [Qualtrics Survey Templates](https://www.qualtrics.com/marketplace/survey-template/)
* Sampling and Sampling size
  + [Sample size calculator](https://www.surveymonkey.com/mp/sample-size-calculator/) - SurveyMonkey
  + [Sample size calculator](https://www.qualtrics.com/blog/calculating-sample-size/) - Qualtrics
  + [Determining-Sample-Size](https://canvas.umn.edu/courses/544898/files/58179483?verifier=S28JQ58j8vWh48gQyCt6WGOIHJnh8KY2fzfmTyMq&wrap=1 "Determining-Sample-Size.pdf") - Qualtrics
  + Panels/Audiences
    - [SurveyMonkey Audience](https://www.surveymonkey.com/product/market-research/audience-panel/)
    - [Qualtrics Panels](https://www.qualtrics.com/research-services/online-sample/)
    - [Mturk](https://www.mturk.com/help)
    - [Prolific](https://www.prolific.com/)
    - [Could Research (TurkPrime)](https://www.cloudresearch.com/)
  + [Sampling gone wrong](https://www.prolific.com/resources/we-recently-went-viral-on-tiktok-heres-what-we-learned) - Prolific (blames TikTok)
  + "Bots" on MTurk: [The BOT problem on MTurk](https://turkrequesters.blogspot.com/2018/08/the-bot-problem-on-mturk.html) and [After the Bot Scare](https://www.cloudresearch.com/resources/blog/after-the-bot-scare-understanding-whats-been-happening-with-data-collection-on-mturk-and-how-to-stop-it/)

Module Details (built in browser, hidden in app)
