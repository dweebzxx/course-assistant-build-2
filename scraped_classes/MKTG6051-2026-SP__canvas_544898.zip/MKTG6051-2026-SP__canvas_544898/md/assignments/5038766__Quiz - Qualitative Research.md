Test your knowledge of this week's materials. You have 20 minutes to complete the quiz.
