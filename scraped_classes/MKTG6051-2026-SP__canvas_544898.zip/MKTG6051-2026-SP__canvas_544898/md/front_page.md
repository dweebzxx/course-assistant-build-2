[![Carlson School building](https://carlsonschool.umn.edu/sites/carlsonschool.umn.edu/files/carlson_canvas_banner.jpg)](https://carlsonschool.umn.edu) 

###### Homepage: Banner

### COURSE MODULES

- [Start Here](https://canvas.umn.edu/courses/544898/modules/2594463)
- [Module 01 (Jan 20 - Jan 25)](https://canvas.umn.edu/courses/544898/pages/module-01-overview "Module 01: Overview")
- [Module 02 (Jan 26 - Feb 1)](https://canvas.umn.edu/courses/544898/pages/module-02-qualitative-research-and-survey-research-part-i "Module 02: Qualitative Research and Survey Research Part I")
- **[Module 03 (Feb 2 - Feb 8)](https://canvas.umn.edu/courses/544898/pages/module-3-survey-research-part-ii "Module 3: Survey Research Part II")**
- [Module 04 (Feb 9 - Feb 15)](https://canvas.umn.edu/courses/544898/pages/module-4-survey-sampling-and-behavioral-testing "Module 4: Survey Sampling and Behavioral Testing")
- [Module 05 (Feb 16 - Feb 22)](https://canvas.umn.edu/courses/544898/pages/module-5-data-cleaning-and-descriptive-analysis "Module 5: Data Cleaning and Descriptive Analysis")
- [Module 06 (Feb 23 - Mar 1)](https://canvas.umn.edu/courses/544898/pages/module-6-linear-regression-analysis "Module 6: Linear Regression Analysis")
- [Module 07 (Mar 2 - Mar 8)](https://canvas.umn.edu/courses/544898/pages/module-7-group-project "Module 7: Logistic Regression Analysis")

[![Carlson School of Management logo](https://carlsonschool.umn.edu/sites/carlsonschool.umn.edu/files/carlson_logo.png)](https://carlsonschool.umn.edu/)

###### Carlson School Logo
